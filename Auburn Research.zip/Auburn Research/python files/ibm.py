from random import randint

def random_int(num_list): 
	print(num_list)
	for i in range(0, len(numlist)):
		random_int = randint(0, len(num_list)-1) # random index in list
        temp = numlist[i]
        newindex = numlist[random_int]
        numlist[i] = newindex
        numlist[random_int] = temp
	print (num_list)
                 
numlist = [1,3,4,5]
random_int(numlist)