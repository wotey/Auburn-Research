import openpyxl

wb = openpyxl.load_workbook('CASIS-25_maps.xlsx')
sheet = wb.get_sheet_by_name('koppel11')

file1 = open("koppel11.txt","a") 

#print (sheet.cell(row=2, column=1).value)
for i in range(2, 102):
    start = sheet.cell(row=i, column=1).value
    end = sheet.cell(row=i, column=2).value
    stringend = "\"" + str(start)[2:4] + "\" -> \"" + str(end)[2:4] +"\" [label = \"" + str(start) + "\"];"
    file1.write(stringend)
    file1.write('\n')

file1.close()