import csv
import os
import networkx as nx


#import pydot
#from networkx.drawing.nx_agraph import write_dot
#from py2neo import Graph, Node, Relationship, Schema, Transaction
import time
#from neo4jrestclient.client import GraphDatabase
import matplotlib.pyplot as plt
#from pygments import style
 
G = nx.Graph()
G.add_node(1)
G.add_node(2)
e = (2, 3) 
G.add_edge(*e)
nx.draw(G)
plt.show()
#db = nx.MultiDiGraph()


        