
import csv
import os
import sys
from py2neo import Graph, Node, Relationship, Schema, Transaction
import time
from neo4jrestclient.client import GraphDatabase
 
db = Graph("https://localhost:11006")
def strip(string): return''.join([c if 0 < ord(c) < 128 else ' ' for c in string])
# Create some nodes with labels


#time.sleep(30)
with open ('CaravelAuthorScores_25.csv', 'r+') as csvfile:
    reader = csv.DictReader(csvfile)
    
    for row in reader: 
        query = """
            MATCH (n) RETURN n LIMIT 25
        """
        score = float(row['1000_1'])
        if (score >= .5):
            author = "Author1"
            AuthorNode = Node("Author", name=author)
            
            #db.run(query)

            actual = row['Author']
            relation = "`1000_1`"
            ActualNode = Node("Author", name=actual)
            
            rel = Relationship(AuthorNode, relation, ActualNode)
            db.create(rel)
            #db.run(query)
        
        
       
    MATCH (a:Author),(b:Author)
    WHERE a.Name = "Author0" AND b.Name = "Author0"
    CREATE (a)-[:`1000_1`]->(b)
    WITH count(*) as dummy
    MATCH (a:Author),(b:Author)
    WHERE a.Name = "Author0" AND b.Name = "Author3"
    CREATE (a)-[:`1000_1`]->(b)
    WITH count(*) as dummy
    MATCH (a:Author),(b:Author)
    WHERE a.Name = "Author0" AND b.Name = "Author4"
    CREATE (a)-[:`1000_1`]->(b)
    WITH count(*) as dummy
    MATCH (a:Author),(b:Author)
    WHERE a.Name = "Author0" AND b.Name = "Author6"
    CREATE (a)-[:`1000_1`]->(b)
    WITH count(*) as dummy
    MATCH (a:Author),(b:Author)
    WHERE a.Name = "Author0" AND b.Name = "Author8"
    CREATE (a)-[:`1000_1`]->(b)
    WITH count(*) as dummy
    MATCH (a:Author),(b:Author)
    WHERE a.Name = "Author0" AND b.Name = "Author10"
    CREATE (a)-[:`1000_1`]->(b)
    WITH count(*) as dummy
    MATCH (a:Author),(b:Author)
    WHERE a.Name = "Author0" AND b.Name = "Author14"
    CREATE (a)-[:`1000_1`]->(b)
    WITH count(*) as dummy
    MATCH (a:Author),(b:Author)
    WHERE a.Name = "Author0" AND b.Name = "Author15"
    CREATE (a)-[:`1000_1`]->(b)
    WITH count(*) as dummy
    MATCH (a:Author),(b:Author)
    WHERE a.Name = "Author0" AND b.Name = "Author17"
    CREATE (a)-[:`1000_1`]->(b)
    WITH count(*) as dummy
    MATCH (a:Author),(b:Author)
    WHERE a.Name = "Author0" AND b.Name = "Author23"
    CREATE (a)-[:`1000_1`]->(b)
