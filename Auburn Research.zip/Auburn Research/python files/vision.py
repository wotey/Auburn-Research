import csv
import sys
import os
import matplotlib.pyplot as plt
import networkx as nx
import pydot 
from networkx.drawing.nx_agraph import to_agraph


G = nx.MultiDiGraph()
with open ('CASIS-25_maps.csv', 'r+') as csvfile:
    reader = csv.DictReader(csvfile)
    for i in range(0, 25):
        a = str(i)
        G.add_node(a)
    for row in reader:
        sample = row['Orignial Instance']
        if int(sample[2:4]) < 10:
            first = sample[3:4]
        else:
            first = sample[2:4]
        second = row['Author Classification']
        if int(second[2:4]) < 10:
            second = second[3:4]
        else:
            second = second[2:4]

        G.add_edge(first, second, r=sample)
    G.graph['edge'] = {'arrowsize': '0.6', 'splines': 'curved'}
    G.graph['graph'] = {'scale': '3'}
    pos=nx.circular_layout(G)
    nx.draw_circular(G, with_labels=True, fontweight='bold')
    edge_labels = nx.get_edge_attributes(G,'r')
    nx.draw_networkx_edge_labels(G,pos=pos)
     

    A = to_agraph(G) 
    A.layout('circo') 
    A.draw('multi.png')  

    
    #G.write_png('outpic.png')
    
    
    #edge_labels = nx.get_edge_attributes(G, 'label')
    plt.show()
    #plt.savefig('outpic.png')
        



