import openpyxl
from py2neo import Graph
from neo4jrestclient.client import GraphDatabase
from py2neo.data import Node, Relationship


first = ""
second = ""
sample = ""
graph = Graph("bolt://localhost:7687", auth=("neo4j", "golly123"))

graph.delete_all()

wb = openpyxl.load_workbook('CASIS-25_maps.xlsx')
adv = openpyxl.load_workbook('CASIS25_sample4AdvMaps.xlsx')
sheet = wb.get_sheet_by_name('keselj03')
advsheet = adv.get_sheet_by_name('keselj03')

'''
for i in range(2, 102):
    start = sheet.cell(row=i, column=1).value
    end = sheet.cell(row=i, column=2).value
    rel = str(start)
    first = str(start)[2:4]
    second = str(end)[2:4]
    if first != second:
        a = Node("Author", name=first)
        b = Node("Author", name=second)
        ab = Relationship(a, rel, b, color='#9453B1' )
        graph.merge(ab, "Author", "name" )
'''
for i in range(2, 27):
    start = advsheet.cell(row=i, column=1).value
    end = advsheet.cell(row=i, column=2).value
    rel = str(start)
    first = str(start)[6:8]
    second = str(end)[2:4]
    if first != second:
        a = Node("Author", name=first)
        b = Node("Author", name=second)
        ab = Relationship(a, rel, b, color='#9453B1' )
        graph.merge(ab, "Author", "name" )
    
    
    








